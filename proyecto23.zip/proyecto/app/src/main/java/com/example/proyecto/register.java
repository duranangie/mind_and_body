package com.example.proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.hardware.biometrics.BiometricManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class register extends AppCompatActivity {

    EditText etname,etphone,etpassword;
    Button etregister;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etname = findViewById(R.id.appCompatEditText);
        etphone = findViewById(R.id.appCompatEditText1);
        etpassword = findViewById(R.id.appCompatEditText2);

        etregister = findViewById(R.id.appCompatButton);

        etregister.setOnClickListener(View ->{
            String name = etname.getText().toString();
            String phone = etphone.getText().toString();
            String password = etpassword.getText().toString();

            if (isValied(name,phone,password)){
                registerUser(name,phone,password);

            }
        });
    }




    public void SignIn(View view){
        Intent intent = new Intent(register.this, login.class);
        startActivity(intent);
    }
    private void showMessage(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }
    private boolean isValied(String name, String phone, String password) {
        if (name.isEmpty()){
            showMessage("please enter username");
            return false;
        }
        if (name.length() > 20 ){
            showMessage("user name is too long ");
            return false;
        }
        if (phone.isEmpty()) {
            showMessage("Please enter phone number");
            return false;
        }
        if (password.isEmpty()) {
            showMessage("please enter password");
            return false;
        }
        if (password.length() <6 || password.length() > 8){
            showMessage("password be between 6 and 8 character");
            return false;

        }
        return true;
    }



    private void registerUser( final String name, final String phone, final String password) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST,Endspoint.register_url, response -> {


            if (response.equals(" success")){

                showMessage("register user");
                Intent intent = new Intent(register.this,login.class);
                startActivity(intent);
            }
            else{

                showMessage("user incorrect ");
                Intent intent = new Intent(register.this,register.class);
                startActivity(intent);
            }

        }, error -> {
            showMessage("please check your internet connection");
            Log.d("VOLLEY",error.getMessage());
            Intent intent = new Intent(register.this,register.class);
            startActivity(intent);
        }){
            protected Map<String, String > getParams(){
                Map<String, String > params = new HashMap<>();
                params.put("name",name);
                params.put("phone",phone);
                params.put("password",password);
                return params;
            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);



    }





}