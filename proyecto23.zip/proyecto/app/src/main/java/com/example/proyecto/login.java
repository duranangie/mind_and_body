package com.example.proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class login extends AppCompatActivity {

    String stn;
    EditText etname,etpassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        etname = findViewById(R.id.appCompatEditText);
        etpassword  = findViewById(R.id.appCompatEditText1);


    }

    public void SignUp(View view){
        Intent intent = new Intent(login.this, register.class);
        startActivity(intent);

    }
    public void login(View view) {
        String uname = etname.getText().toString();
        String password = etpassword.getText().toString();

        if (isValied(uname  , password)) {
            signIn(uname, password);
        }


    }

    private void showMessage(String msg) {

        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }


    private boolean isValied(String uname, String password) {

        if (uname.isEmpty()) {
            showMessage("user name is empty");
            etname.setText(null);
            return false;
        }
        if (password.isEmpty()) {
            showMessage("password is empty");
            etpassword.setText(null);
            return false;

        }
        return true;
    }


    private void signIn(final String uname, final String password) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST,Endspoint.login_url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                stn = etname.getText().toString();

                if (response.equals(" success")) {
                    Intent intent = new Intent(login.this, MainActivity2.class);
                    intent.putExtra("uname", stn);
                    startActivity(intent);
                    etname.setText(null);
                    etpassword.setText(null);
                }
                if (response.equals(" INVALIED")) {
                    showMessage("invalied user password");
                    Intent intent = new Intent(login.this, login.class);
                    startActivity(intent);
                    etname.setText(null);
                    etpassword.setText(null);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                showMessage("please check you internet connection");
                Log.d("VOLLEY",error.getMessage());
                Intent intent = new Intent(login.this, login.class);
                startActivity(intent);
            }
        }) {
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("uname", uname);
                params.put("password", password);
                return params;
            }

        };


        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);

    }
}
