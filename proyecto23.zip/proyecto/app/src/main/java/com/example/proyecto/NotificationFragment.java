package com.example.proyecto;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 */
public class NotificationFragment extends Fragment {

    private EditText txtPliegueTriceps;
    private EditText txtPliegueAbdomen;
    private EditText txtPliegueMuslo,txtEdad;

    private RadioGroup radioGroupSexo;

    public NotificationFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_notification, container, false);

        txtPliegueTriceps = rootView.findViewById(R.id.txtPliegueTriceps);
        txtPliegueAbdomen = rootView.findViewById(R.id.txtPliegueAbdomen);
        txtPliegueMuslo = rootView.findViewById(R.id.txtPliegueMuslo);

         txtEdad = rootView.findViewById(R.id.txtEdad);
         radioGroupSexo = rootView.findViewById(R.id.radioGroupSexo);

        Button btnCalcular = rootView.findViewById(R.id.btnCalcularPorcentajeGrasa);
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularPorcentajeGrasa();
            }
        });

        return rootView;
    }

    private void calcularPorcentajeGrasa() {
        String pliegueTricepsTexto = txtPliegueTriceps.getText().toString();
        String pliegueAbdomenTexto = txtPliegueAbdomen.getText().toString();
        String pliegueMusloTexto = txtPliegueMuslo.getText().toString();
        String edadTexto = txtEdad.getText().toString();



        if (pliegueTricepsTexto.equals("") || pliegueAbdomenTexto.equals("") || pliegueMusloTexto.equals("")) {
            Toast.makeText(getActivity(), "Por favor llene los datos", Toast.LENGTH_LONG).show();
        } else {
            float pliegueTriceps = Float.parseFloat(pliegueTricepsTexto);
            float pliegueAbdomen = Float.parseFloat(pliegueAbdomenTexto);
            float pliegueMuslo = Float.parseFloat(pliegueMusloTexto);

            // Suma de los pliegues cutáneos
            float sumaPliegues = pliegueTriceps + pliegueAbdomen + pliegueMuslo;

            // Ingresa la edad y el sexo de la persona
            int edad = Integer.parseInt(edadTexto); // Cambia esto por la edad real de la persona
            boolean esHombre; // Cambia esto según el sexo de la persona

            // Cálculo del porcentaje de grasa corporal
            float porcentajeGrasa;
            int selectedRadioButtonId = radioGroupSexo.getCheckedRadioButtonId();
            if (selectedRadioButtonId  == R.id.radioHombre) {
                esHombre = true;
                porcentajeGrasa = (1.20f * sumaPliegues) - (0.23f * edad) - 16.2f;
            } else if (selectedRadioButtonId  == R.id.radioMujer) {
                esHombre = false;
                porcentajeGrasa = (1.20f * sumaPliegues) - (0.23f * edad) - 5.4f;
            } else {
            // No se seleccionó ningún sexo
            Toast.makeText(getActivity(), "Por favor selecciona el sexo", Toast.LENGTH_LONG).show();
            return;
        }

            // Mostrar el resultado en un Toast
            String resultadoTexto = String.format("%.1f", porcentajeGrasa);
            Toast.makeText(getActivity(), "El porcentaje de grasa corporal es: " + resultadoTexto, Toast.LENGTH_LONG).show();
        }
    }
}