package com.example.proyecto;

public class Endspoint {
    private static final String base_url = "https://proyectgym.000webhostapp.com/";
    public static final String register_url = base_url + "register.php";
    public static final String login_url = base_url + "new.php";


}
