package com.example.proyecto;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 */
public class SettingsFragment extends Fragment {

    private EditText txtNumero1;
    private EditText txtNumero2;
    private EditText txtNumero3;

    public SettingsFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);
        txtNumero1 = view.findViewById(R.id.txtNumero1);
        txtNumero2 = view.findViewById(R.id.txtNumero2);
        txtNumero3 = view.findViewById(R.id.txtNumero3);

        Button btnIMC = view.findViewById(R.id.button);
        btnIMC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularIMC();
            }
        });

        return view;
    }

    private void calcularIMC() {
        String numero1Texto = txtNumero1.getText().toString();
        String numero2Texto = txtNumero2.getText().toString();
        String numero3Texto = txtNumero3.getText().toString();
        if (numero1Texto.equals("") || numero2Texto.equals("") || numero3Texto.equals("")) {
            Toast.makeText(getActivity(), "Por favor llene los datos", Toast.LENGTH_LONG).show();
        } else {
            int numero1 = Integer.parseInt(numero1Texto);
            float numero2 = Float.parseFloat(numero2Texto);
            float numero3 = Float.parseFloat(numero3Texto);
            numero3 = numero3 / 100;
            // Proceso de calcular el índice de masa corporal
            float imc = numero2 / (float) Math.pow(numero3, 2);
            // Convirtiendo el resultado a texto
            String imcTexto = String.format("%.1f", imc);
            if (imc < 18.5f)
                Toast.makeText(getActivity(), "edad: " + numero1 + " IMC: " + imcTexto + " tiene Desnutrición", Toast.LENGTH_LONG).show(); // Desnutrición
            else if (imc >= 18.5f && imc < 25)
                Toast.makeText(getActivity(), "edad: " + numero1 + " IMC: " + imcTexto + "  está Normal", Toast.LENGTH_LONG).show(); // Normal
            else if (imc >= 25 && imc < 30)
                Toast.makeText(getActivity(), "edad: " + numero1 + " IMC: " + imcTexto + " tiene Sobrepeso", Toast.LENGTH_LONG).show(); // Sobrepeso
            else if (imc >= 30 && imc < 35)
                Toast.makeText(getActivity(), "edad: " + numero1 + " IMC: " + imcTexto + " tiene Obesidad Grado 1", Toast.LENGTH_LONG).show(); // Obesidad Grado 1
            else if (imc >= 35 && imc < 40)
                Toast.makeText(getActivity(), "edad: " + numero1 + " IMC: " + imcTexto + " tiene Obesidad Grado 2", Toast.LENGTH_LONG).show(); // Obesidad Grado 2
            else if (imc >= 40)
                Toast.makeText(getActivity(), "edad: " + numero1 + " IMC: " + imcTexto + " tiene Obesidad Grado 3", Toast.LENGTH_LONG).show(); // Obesidad Grado 3

        }
    }
}