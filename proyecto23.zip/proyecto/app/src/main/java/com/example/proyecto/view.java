package com.example.proyecto;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.TelephonyManager;
import android.telephony.SmsManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class view extends AppCompatActivity implements View.OnClickListener {

    EditText ednombre, edtelefono, edcedula, edcorreo, eddireccion, edn_emergencia, edpeso_inicial, edregistro_peso,edcintura,edgrasa,edimc,edlesiones,edenfermedad,edemergencia, edId;

    Button btnbuscar, btncreate;
    Spinner edmetas, edsemana, eddias, edhorario, edrutina,eddieta,Lesion,Sick;

    TextView plan,ventas,dias,horario,rutina,dieta,rendimiento,pesito,composicion,registrosema,grasa;

    RequestQueue requestQueue;

    private static final String URLI = "https://proyectgym.000webhostapp.com/insertar.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        requestQueue = Volley.newRequestQueue(this);

        //UI
        initUI();
        btncreate.setOnClickListener(this);
        btnbuscar.setOnClickListener(this);
    }

    private void initUI() {
        ednombre = findViewById(R.id.ednombre);
        edtelefono = findViewById(R.id.edtelefono);
        edcedula = findViewById(R.id.edcedula);
        edcorreo = findViewById(R.id.edcorreo);
        eddireccion = findViewById(R.id.eddireccion);
        edn_emergencia = findViewById(R.id.edn_emergencia);
        edId = findViewById(R.id.edId);
        edmetas = findViewById(R.id.edmetas);
        edsemana = findViewById(R.id.edsemana);
        eddias = findViewById(R.id.eddias);
        edhorario = findViewById(R.id.edhorario);
        edpeso_inicial = findViewById(R.id.edpeso_inicial);
        edregistro_peso = findViewById(R.id.edregistro_peso);
        edrutina = findViewById(R.id.edrutina);
        eddieta = findViewById(R.id.eddieta);
        edimc = findViewById(R.id.edimc);
        edgrasa = findViewById(R.id.edgrasa);
        edcintura = findViewById(R.id.edcintura);
        edlesiones = findViewById(R.id.edlesiones);
        edenfermedad = findViewById(R.id.edenfermedad);
        edemergencia = findViewById(R.id.edemergencia);
        Lesion  = findViewById(R.id.Lesion);
        Sick  = findViewById(R.id.Sick);







        // Configurar opciones del Spinner
        ArrayList<String> opcionesmetas = new ArrayList<>();
        opcionesmetas.add("Ingresa tu meta");
        opcionesmetas.add("bajar de peso");
        opcionesmetas.add("subir de peso");
        opcionesmetas.add("tonificar");

        ArrayAdapter<String> adaptermetas = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionesmetas);
        edmetas.setAdapter(adaptermetas);


        // Spinner para la opción de semana
        Spinner spinnerSemana = findViewById(R.id.edsemana);

        ArrayList<String> opcionesSemana = new ArrayList<>();
        opcionesSemana.add("1");
        opcionesSemana.add("2");
        opcionesSemana.add("3");
        opcionesSemana.add("4");

        ArrayAdapter<String> adapterSemana = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionesSemana);
        spinnerSemana.setAdapter(adapterSemana);


        // Spinner para la opción de días
        Spinner spinnerDias = findViewById(R.id.eddias);

        ArrayList<String> opcionesDias = new ArrayList<>();
        opcionesDias.add("agenda los dias");
        opcionesDias.add("jueves viernes sabado");
        opcionesDias.add("lunes martes mieroles");
        opcionesDias.add("lunes miercoles viernes");
        opcionesDias.add("todos los dias");



        ArrayAdapter<String> adapterDias = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionesDias);
        spinnerDias.setAdapter(adapterDias);

        // Spinner para la opción de horario
        Spinner spinnerHorario = findViewById(R.id.edhorario);

        ArrayList<String> opcionesHorario = new ArrayList<>();
        opcionesHorario.add("ingresa el horario");
        opcionesHorario.add("5:00");
        opcionesHorario.add("6:00");
        opcionesHorario.add("7:00");
        opcionesHorario.add("8:00");
        opcionesHorario.add("9:00");
        opcionesHorario.add("10:00");
        opcionesHorario.add("11:00");
        opcionesHorario.add("12:00");
        opcionesHorario.add("13:00");
        opcionesHorario.add("14:00");
        opcionesHorario.add("15:00");
        opcionesHorario.add("16:00");
        opcionesHorario.add("17:00");
        opcionesHorario.add("18:00");
        opcionesHorario.add("19:00");
        opcionesHorario.add("20:00");
        opcionesHorario.add("21:00");

        ArrayAdapter<String> adapterHorario = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionesHorario);
        spinnerHorario.setAdapter(adapterHorario);
    // Configurar opciones del Spinner
        ArrayList<String> opcionesrutina = new ArrayList<>();
        opcionesrutina.add("ingresa la rutina");
        opcionesrutina.add("piernas y gluteos");
        opcionesrutina.add("plank power");
        opcionesrutina.add("brazos");
        opcionesrutina.add("fuerza abdominal");

        ArrayAdapter<String> adapterRutina = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionesrutina);
        edrutina.setAdapter(adapterRutina);

        // Spinner para la opción de semana
        ArrayList<String> opcionesdieta = new ArrayList<>();
        opcionesdieta.add("ingresa la dieta");
        opcionesdieta.add("Dieta para aumentar masa muscular:Desayuno: Batido de proteínas con avena, plátano y leche desnatada.\nMerienda de la mañana: Yogur griego con nueces y frutas.\nAlmuerzo: Pechuga de pollo a la parrilla con arroz integral y verduras al vapor.\nMerienda de la tarde: Batido de proteínas con mantequilla de maní y plátano.\nCena: Salmón a la plancha con quinoa y ensalada mixta.\nAntes de dormir: Caseína o yogur griego bajo en grasa.\n\n\n\n");

        opcionesdieta.add("Dieta para pérdida de grasa: Desayuno: Tortilla de claras de huevo con espinacas y tomates.\n Merienda de la mañana: Batido de proteínas con almendras y bayas.\n Almuerzo: Ensalada de pollo a la parrilla con aguacate y vinagreta ligera.\n Merienda de la tarde: Rodajas de pepino con hummus.\n Cena: Filete de salmón al horno con espárragos y quinoa.\n Antes de dormir: Batido de proteínas con leche de almendras.\n\n\n\n");

        opcionesdieta.add("Dieta para mejorar el rendimiento deportivo:Desayuno: Tostadas integrales con aguacate, huevo y espinacas.\nMerienda de la mañana: Batido de proteínas con frutas y avena.\nAlmuerzo: Pasta integral con pollo a la parrilla, verduras y salsa de tomate.\nMerienda de la tarde: Yogur griego con miel y nueces.\nCena: Ensalada de quinoa con salmón ahumado, aguacate y vegetales.\nAntes de dormir: Batido de proteínas con leche de almendras.");

        ArrayAdapter<String> adaptardieta = new ArrayAdapter<>(this, R.layout.spinner_item, opcionesdieta);
        eddieta.setAdapter(adaptardieta);







        // Spinner para la opción de horario
        ArrayList<String> opcioneslesion = new ArrayList<>();
        opcioneslesion.add("Sin lesiones");
        opcioneslesion.add("combinacion");
        opcioneslesion.add("torso");
        opcioneslesion.add("codo");
        opcioneslesion.add("tobillo");
        opcioneslesion.add("cadera");
        opcioneslesion.add("rodilla");
        opcioneslesion.add("cuello");
        opcioneslesion.add("muñeca");
        opcioneslesion.add("hombro");
        opcioneslesion.add("dedos");
        opcioneslesion.add("espina dorsal");
        ArrayAdapter<String> adapterlesion = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcioneslesion);
        Lesion.setAdapter(adapterlesion);




        // Spinner para la opción de horario
        ArrayList<String> opcionessick = new ArrayList<>();
        opcionessick.add("Sin enfermedad cronica");
        opcionessick.add("Quemado");
        opcionessick.add("sindrome de fatiga cronica (SFC)");
        opcionessick.add("cancer");
        opcionessick.add("enfermedades cardiovasculares");
        opcionessick.add("enfermedades cronicas pulmones EPOC Y ASMA");
        opcionessick.add("lesiones en espalda, hombros, cuello");
        opcionessick.add("diabetes tipo2");
        opcionessick.add("fibromialgia");
        opcionessick.add("Osteoporosis");
        opcionessick.add("sobrepeso/obesidad");
        opcionessick.add("Artritis rematoide");


        ArrayAdapter<String> adaptersick = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionessick);
        Sick.setAdapter(adaptersick);






        btncreate = findViewById(R.id.btncreate);
        btnbuscar = findViewById(R.id.btnbuscar);
    }


    @Override
    public void onClick(View view) {
        int id = view.getId();

        if (id == R.id.btncreate) {
            String nombre = ednombre.getText().toString().trim();
            String telefono = edtelefono.getText().toString().trim();
            String cedula = edcedula.getText().toString().trim();
            String correo = edcorreo.getText().toString().trim();
            String direccion = eddireccion.getText().toString().trim();
            String n_emergencia = edn_emergencia.getText().toString().trim();
            String id_metas = edmetas.getSelectedItem().toString().trim();
            String id_semanas = edsemana.getSelectedItem().toString().trim();
            String id_dias = eddias.getSelectedItem().toString().trim();
            String horario = edhorario.getSelectedItem().toString().trim();
            String peso_inicial = edpeso_inicial.getText().toString().trim();
            String registro_peso = edregistro_peso.getText().toString().trim();
            String rutina = edrutina.getSelectedItem().toString().trim();
            String dieta = eddieta.getSelectedItem().toString().trim();
            String imc = edimc.getText().toString().trim();
            String cintura = edcintura.getText().toString().trim();
            String masa = edgrasa.getText().toString().trim();
            String descripcion1 = edlesiones.getText().toString().trim();
            String descripcion2 = edenfermedad.getText().toString().trim();
            String emergencia = edemergencia.getText().toString().trim();
            String lesion = Lesion.getSelectedItem().toString().trim();
            String sick = Sick.getSelectedItem().toString().trim();

















            createUser(nombre, telefono, cedula, correo, direccion, n_emergencia, id_metas, id_semanas, id_dias, horario , peso_inicial, registro_peso, rutina, dieta, imc, cintura, masa, descripcion1,descripcion2,emergencia,lesion,sick );

        } else if (id == R.id.btnbuscar) {
            Intent intent = new Intent(this, view2.class);
            intent.putExtra("id", edId.getText().toString().trim());
            startActivity(intent);


    }
    }

    private void createUser(final String nombre, final String telefono, final String cedula, final String correo, final String direccion, final String n_emergencia, final String id_metas , final String id_semanas , final String id_dias , final String horario , final String peso_inicial , final String registro_peso , final String rutina, final String dieta,final String imc,final String cintura,final String masa , final String descripcion1, final String descripcion2,final String emergencia, final String lesion, final String sick ) {

        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                URLI,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Mostrar el mensaje con el ID registrado
                        mostrarMensaje("Tu numero de registro es : " + response);

                        // Obtener el número de teléfono ingresado por el usuario
                        String telefono = edtelefono.getText().toString();

                        // Enviar el mensaje de texto
                        String message = "recuerda que este numero te identica si quieres tener los avances de tus rutinas: " + response;
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(telefono, null, message, null, null);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("nombre", nombre);
                params.put("telefono", telefono);
                params.put("cedula", cedula);
                params.put("correo", correo);
                params.put("direccion", direccion);
                params.put("n_emergencia", n_emergencia);
                params.put("id_metas", id_metas);
                params.put("id_semanas", id_semanas);
                params.put("id_dias", id_dias);
                params.put("horario", horario);
                params.put("peso_inicial", peso_inicial);
                params.put("registro_peso", registro_peso);
                params.put("rutina", rutina);
                params.put("dieta", dieta);
                params.put("imc", imc);
                params.put("cintura", cintura);
                params.put("masa", masa);
                params.put("descripcion1", descripcion1);
                params.put("descripcion2", descripcion2);
                params.put("emergencia", emergencia);
                params.put("lesion", lesion);
                params.put("sick", sick);
                return params;

            }
        };

        requestQueue.add(stringRequest);
    }

    private void mostrarMensaje(String mensaje) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }

}