package com.example.proyecto;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class view2 extends AppCompatActivity implements View.OnClickListener {

    EditText ednombre, edtelefono, edcedula, edcorreo, eddireccion, edn_emergencia, edpeso_inicial, edregistro_peso,edcintura,edgrasa,edimc,edlesiones,edenfermedad,edemergencia, edId;
    Button btnedit, btndelete, btnrendimiento, btnplan,btnmedica,btnnota;
    Spinner edmetas, edsemana, eddias, edhorario, edrutina,eddieta,Lesion,Sick;

    TextView plan,ventas,dias,horario,rutina,dieta,rendimiento,pesito,composicion,registrosema,grasa,uno,dos,tres,cuatro,imc,imcc,cuenta,medica,lesiones,les,enfermedad,enfer,contacto;

    RequestQueue requestQueue;

    String id;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view2);


        requestQueue = Volley.newRequestQueue(this);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            id = extras.getString("id");
        }



        // UI
        initUI();
        readUser();

        btnedit.setOnClickListener(this);
        btndelete.setOnClickListener(this);
        btnrendimiento.setOnClickListener(this);
        btnplan.setOnClickListener(this);
        btnmedica.setOnClickListener(this);
        btnnota.setOnClickListener(this);

    }

    private void initUI() {
        ednombre = findViewById(R.id.ednombre);
        edtelefono = findViewById(R.id.edtelefono);
        edcedula = findViewById(R.id.edcedula);
        edcorreo = findViewById(R.id.edcorreo);
        eddireccion = findViewById(R.id.eddireccion);
        edn_emergencia = findViewById(R.id.edn_emergencia);
        edId = findViewById(R.id.edId);
        edmetas = findViewById(R.id.edmetas);
        edsemana = findViewById(R.id.edsemana);
        eddias = findViewById(R.id.eddias);
        edhorario = findViewById(R.id.edhorario);
        edpeso_inicial = findViewById(R.id.edpeso_inicial);
        edregistro_peso = findViewById(R.id.edregistro_peso);
        edrutina = findViewById(R.id.edrutina);
        eddieta = findViewById(R.id.eddieta);
        plan = findViewById(R.id.plan);
        ventas = findViewById(R.id.ventas);
        dias = findViewById(R.id.dias);
        horario = findViewById(R.id.horario);
        rutina = findViewById(R.id.rutina);
        dieta = findViewById(R.id.dieta);
        rendimiento = findViewById(R.id.rendimiento);
        pesito = findViewById(R.id.pesito);
        composicion = findViewById(R.id.composicion);
        registrosema = findViewById(R.id.registrosema);
        grasa = findViewById(R.id.grasa);
        edcintura = findViewById(R.id.edcintura);
        edgrasa = findViewById(R.id.edgrasa);
        edimc = findViewById(R.id.edimc);
        uno = findViewById(R.id.uno);
        dos = findViewById(R.id.dos);
        tres = findViewById(R.id.tres);
        cuatro = findViewById(R.id.cuatro);
        imc = findViewById(R.id.imc);
        imcc = findViewById(R.id.imcc);
        cuenta = findViewById(R.id.cuenta);
        medica = findViewById(R.id.medica);
        lesiones = findViewById(R.id.lesiones);
        Lesion = findViewById(R.id.Lesion);
        les = findViewById(R.id.les);
        edlesiones = findViewById(R.id.edlesiones);
        enfermedad = findViewById(R.id.enfermedad);
        enfer = findViewById(R.id.enfer);
        contacto = findViewById(R.id.contacto);
        Sick = findViewById(R.id.Sick);
        edenfermedad = findViewById(R.id.edenfermedad);
        edemergencia = findViewById(R.id.edemergencia);





        // Configurar opciones del Spinner
        ArrayList<String> opcionesmetas = new ArrayList<>();
        opcionesmetas.add("Ingresa tu meta");
        opcionesmetas.add("bajar de peso");
        opcionesmetas.add("subir de peso");
        opcionesmetas.add("tonificar");

        ArrayAdapter<String> adapterMetas = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionesmetas);
        edmetas.setAdapter(adapterMetas);

        // Spinner para la opción de semana
        ArrayList<String> opcionesSemana = new ArrayList<>();
        opcionesSemana.add("1");
        opcionesSemana.add("2");
        opcionesSemana.add("3");
        opcionesSemana.add("4");

        ArrayAdapter<String> adapterSemana = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionesSemana);
        edsemana.setAdapter(adapterSemana);

        // Spinner para la opción de días
        ArrayList<String> opcionesDias = new ArrayList<>();
        opcionesDias.add("agenda los dias");
        opcionesDias.add("jueves viernes sabado");
        opcionesDias.add("lunes martes mieroles");
        opcionesDias.add("lunes miercoles viernes");
        opcionesDias.add("todos los dias");

        ArrayAdapter<String> adapterDias = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionesDias);
        eddias.setAdapter(adapterDias);

        // Spinner para la opción de horario
        ArrayList<String> opcionesHorario = new ArrayList<>();
        opcionesHorario.add("ingresa el horario");
        opcionesHorario.add("5:00");
        opcionesHorario.add("6:00");
        opcionesHorario.add("7:00");
        opcionesHorario.add("8:00");
        opcionesHorario.add("9:00");
        opcionesHorario.add("10:00");
        opcionesHorario.add("11:00");
        opcionesHorario.add("12:00");
        opcionesHorario.add("13:00");
        opcionesHorario.add("14:00");
        opcionesHorario.add("15:00");
        opcionesHorario.add("16:00");
        opcionesHorario.add("17:00");
        opcionesHorario.add("18:00");
        opcionesHorario.add("19:00");
        opcionesHorario.add("20:00");
        opcionesHorario.add("21:00");

        ArrayAdapter<String> adapterHorario = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionesHorario);
        edhorario.setAdapter(adapterHorario);

        // Spinner para la opción de semana
        ArrayList<String> opcionesrutina = new ArrayList<>();
        opcionesrutina.add("ingresa la rutina");
        opcionesrutina.add("piernas y gluteos");
        opcionesrutina.add("plank power");
        opcionesrutina.add("brazos");
        opcionesrutina.add("fuerza abdominal");

        ArrayAdapter<String> adaptarrutina = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionesrutina);
        edrutina.setAdapter(adaptarrutina);

        // Spinner para la opción de semana
        ArrayList<String> opcionesdieta = new ArrayList<>();
        opcionesdieta.add("\n");
        opcionesdieta.add("ingresa la dieta");
        opcionesdieta.add("\n");
        opcionesdieta.add("Dieta para aumentar masa muscular:Desayuno: Batido de proteínas con avena, plátano y leche desnatada.\nMerienda de la mañana: Yogur griego con nueces y frutas.\nAlmuerzo: Pechuga de pollo a la parrilla con arroz integral y verduras al vapor.\nMerienda de la tarde: Batido de proteínas con mantequilla de maní y plátano.\nCena: Salmón a la plancha con quinoa y ensalada mixta.\nAntes de dormir: Caseína o yogur griego bajo en grasa.");
        opcionesdieta.add("\n");
        opcionesdieta.add("Dieta para pérdida de grasa: Desayuno: Tortilla de claras de huevo con espinacas y tomates.\n Merienda de la mañana: Batido de proteínas con almendras y bayas.\n Almuerzo: Ensalada de pollo a la parrilla con aguacate y vinagreta ligera.\n Merienda de la tarde: Rodajas de pepino con hummus.\n Cena: Filete de salmón al horno con espárragos y quinoa.\n Antes de dormir: Batido de proteínas con leche de almendras.");
        opcionesdieta.add("\n");
        opcionesdieta.add("Dieta para mejorar el rendimiento deportivo:Desayuno: Tostadas integrales con aguacate, huevo y espinacas.\nMerienda de la mañana: Batido de proteínas con frutas y avena.\nAlmuerzo: Pasta integral con pollo a la parrilla, verduras y salsa de tomate.\nMerienda de la tarde: Yogur griego con miel y nueces.\nCena: Ensalada de quinoa con salmón ahumado, aguacate y vegetales.\nAntes de dormir: Batido de proteínas con leche de almendras.");

        ArrayAdapter<String> adaptardieta = new ArrayAdapter<>(this, R.layout.spinner_item, opcionesdieta);
        eddieta.setAdapter(adaptardieta);





        // Spinner para la opción de horario
        ArrayList<String> opcioneslesion = new ArrayList<>();
        opcioneslesion.add("Sin lesiones");
        opcioneslesion.add("combinacion");
        opcioneslesion.add("torso");
        opcioneslesion.add("codo");
        opcioneslesion.add("tobillo");
        opcioneslesion.add("cadera");
        opcioneslesion.add("rodilla");
        opcioneslesion.add("cuello");
        opcioneslesion.add("muñeca");
        opcioneslesion.add("hombro");
        opcioneslesion.add("dedos");
        opcioneslesion.add("espina dorsal");
        ArrayAdapter<String> adapterlesion = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcioneslesion);
        Lesion.setAdapter(adapterlesion);


        // Spinner para la opción de horario
        ArrayList<String> opcionessick = new ArrayList<>();
        opcionessick.add("Sin enfermedad cronica");
        opcionessick.add("Quemado");
        opcionessick.add("sindrome de fatiga cronica (SFC)");
        opcionessick.add("cancer");
        opcionessick.add("enfermedades cardiovasculares");
        opcionessick.add("enfermedades cronicas pulmones EPOC Y ASMA");
        opcionessick.add("lesiones en espalda, hombros, cuello");
        opcionessick.add("diabetes tipo2");
        opcionessick.add("fibromialgia");
        opcionessick.add("Osteoporosis");
        opcionessick.add("sobrepeso/obesidad");
        opcionessick.add("Artritis rematoide");


        ArrayAdapter<String> adaptersick = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionessick);
        Sick.setAdapter(adaptersick);







        btnedit = findViewById(R.id.btnedit);
        btndelete = findViewById(R.id.btndelete);
        btnrendimiento = findViewById(R.id.btnrendimiento);
        btnplan = findViewById(R.id.btnplan);
        btnmedica = findViewById(R.id.btnmedica);
        btnnota = findViewById(R.id.btnnota);

        // Restaurar la visibilidad de las opciones ocultas
        edmetas.setVisibility(View.VISIBLE);
        eddias.setVisibility(View.VISIBLE);
        edhorario.setVisibility(View.VISIBLE);
        edrutina.setVisibility(View.VISIBLE);
        eddieta.setVisibility(View.VISIBLE);
        edpeso_inicial.setVisibility(View.GONE);
        edsemana.setVisibility(View.GONE);
        edregistro_peso.setVisibility(View.GONE);
        edimc.setVisibility(View.GONE);
        edcintura.setVisibility(View.GONE);
        edgrasa.setVisibility(View.GONE);
        rendimiento.setVisibility(View.GONE);
        pesito.setVisibility(View.GONE);
        edcintura.setVisibility(View.GONE);
        edgrasa.setVisibility(View.GONE);
        uno.setVisibility(View.GONE);
        dos.setVisibility(View.GONE);
        tres.setVisibility(View.GONE);
        cuatro.setVisibility(View.GONE);
        registrosema.setVisibility(View.GONE);
        grasa.setVisibility(View.GONE);
        composicion.setVisibility(View.GONE);
        imc.setVisibility(View.GONE);
        imcc.setVisibility(View.GONE);
        cuenta.setVisibility(View.GONE);
        medica.setVisibility(View.GONE);
        lesiones.setVisibility(View.GONE);
         Lesion.setVisibility(View.GONE);
         les.setVisibility(View.GONE);
         edlesiones.setVisibility(View.GONE);
         enfermedad.setVisibility(View.GONE);
         enfer.setVisibility(View.GONE);
        contacto.setVisibility(View.GONE);
         Sick.setVisibility(View.GONE);
        edenfermedad.setVisibility(View.GONE);
        edemergencia.setVisibility(View.GONE);
        edn_emergencia.setVisibility(View.GONE);
        edtelefono.setVisibility(View.GONE);
        edcedula.setVisibility(View.GONE);
        edcorreo.setVisibility(View.GONE);
        eddireccion.setVisibility(View.GONE);
    }

    private void readUser() {
        String URL = "https://proyectgym.000webhostapp.com/fetch.php?id=" + id;
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                URL,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        String nombre,telefono,cedula,correo,direccion,n_emergencia,id_metas,id_semanas,id_dias,horario,peso_inicial,registro_peso,rutina,dieta,imc,cintura,masa,lesion,descripcion1,sick,descripcion2,emergencia;
                        try {

                            // Obtener los datos del usuario
                            nombre = response.getString("nombre");
                            telefono = response.getString("telefono");
                            cedula = response.getString("cedula");
                            correo = response.getString("correo");
                            direccion = response.getString("direccion");
                            n_emergencia = response.getString("n_emergencia");
                            id_metas = response.getString("id_metas");
                            id_semanas = response.getString("id_semanas");
                            id_dias = response.getString("id_dias");
                            horario = response.getString("horario");
                            peso_inicial = response.getString("peso_inicial");
                            registro_peso = response.getString("registro_peso");
                            rutina = response.getString("rutina");
                            dieta = response.getString("dieta");
                            imc = response.getString("imc");
                            masa = response.getString("masa");
                            cintura = response.getString("cintura");
                            lesion = response.getString("lesion");
                            descripcion1 = response.getString("descripcion1");
                            sick = response.getString("sick");
                            descripcion2 = response.getString("descripcion2");
                            emergencia = response.getString("emergencia");

                            // Establecer los valores en los campos correspondientes
                            ednombre.setText(nombre);
                            edtelefono.setText(telefono);
                            edcedula.setText(cedula);
                            edcorreo.setText(correo);
                            eddireccion.setText(direccion);
                            edn_emergencia.setText(n_emergencia);
                            edmetas.setSelection(((ArrayAdapter<String>)edmetas.getAdapter()).getPosition(id_metas));
                            edsemana.setSelection(Integer.parseInt(id_semanas)-1);
                            eddias.setSelection(((ArrayAdapter<String>)eddias.getAdapter()).getPosition(id_dias));
                            edhorario.setSelection(((ArrayAdapter<String>)edhorario.getAdapter()).getPosition(horario));
                            edpeso_inicial.setText(peso_inicial);
                            edregistro_peso.setText(registro_peso);
                            edrutina.setSelection(((ArrayAdapter<String>)edrutina.getAdapter()).getPosition(rutina));
                            eddieta.setSelection(((ArrayAdapter<String>) eddieta.getAdapter()).getPosition(dieta));
                            edimc.setText(imc);
                            edcintura.setText(cintura);
                            edgrasa.setText(masa);
                            Lesion.setSelection(((ArrayAdapter<String>) Lesion.getAdapter()).getPosition(lesion));
                            edlesiones.setText(descripcion1);
                            Sick.setSelection(((ArrayAdapter<String>)Sick.getAdapter()).getPosition(sick));
                            edenfermedad.setText(descripcion2);
                            edemergencia.setText(emergencia);




                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }

        );

        requestQueue.add(jsonObjectRequest);
    }




    @Override
    public void onClick(View view) {

        int id = view.getId();

        if (id == R.id.btnedit) {

            String nombre = ednombre.getText().toString().trim();
            String telefono = edtelefono.getText().toString().trim();
            String cedula = edcedula.getText().toString().trim();
            String correo = edcorreo.getText().toString().trim();
            String direccion = eddireccion.getText().toString().trim();
            String n_emergencia = edn_emergencia.getText().toString().trim();
            String id_metas = edmetas.getSelectedItem().toString().trim();
            String id_semanas = edsemana.getSelectedItem().toString().trim();
            String id_dias = eddias.getSelectedItem().toString().trim();
            String horario = edhorario.getSelectedItem().toString().trim();
            String peso_inicial = edpeso_inicial.getText().toString().trim();
            String registro_peso = edregistro_peso.getText().toString().trim();
            String rutina = edrutina.getSelectedItem().toString().trim();
            String dieta = eddieta.getSelectedItem().toString().trim();
            String imc = edimc.getText().toString().trim();
            String cintura = edcintura.getText().toString().trim();
            String masa = edgrasa.getText().toString().trim();
            String lesion = Lesion.getSelectedItem().toString().trim();
            String descripcion1 = edlesiones.getText().toString().trim();
            String sick = Sick.getSelectedItem().toString().trim();
            String descripcion2 = edenfermedad.getText().toString().trim();
            String emergencia = edemergencia.getText().toString().trim();


            updateUser(nombre, telefono, cedula, correo, direccion, n_emergencia, id_metas, id_semanas, id_dias, horario, peso_inicial, registro_peso, rutina,  dieta,imc,cintura,masa,lesion,descripcion1,sick,descripcion2,emergencia);

        }else if (id == R.id.btnrendimiento) {

            // Ocultar las demás opciones


            edn_emergencia.setVisibility(View.GONE);
             Sick.setVisibility(View.GONE);
             contacto.setVisibility(View.GONE);
             enfer.setVisibility(View.GONE);
             edlesiones.setVisibility(View.GONE);
             les.setVisibility(View.GONE);
             Lesion.setVisibility(View.GONE);
             lesiones.setVisibility(View.GONE);
             edenfermedad.setVisibility(View.GONE);
             edemergencia.setVisibility(View.GONE);
             medica.setVisibility(View.GONE);
             enfermedad.setVisibility(View.GONE);
            cuenta.setVisibility(View.GONE);
            edmetas.setVisibility(View.GONE);
            edsemana.setVisibility(View.GONE);
            eddias.setVisibility(View.GONE);
            edhorario.setVisibility(View.GONE);
            edrutina.setVisibility(View.GONE);
            eddieta.setVisibility(View.GONE);
            plan.setVisibility(View.GONE);
            ventas.setVisibility(View.GONE);
            dias.setVisibility(View.GONE);
            horario.setVisibility(View.GONE);
            rutina.setVisibility(View.GONE);
            dieta.setVisibility(View.GONE);
            edtelefono.setVisibility(View.GONE);
            edcedula.setVisibility(View.GONE);
            edcorreo.setVisibility(View.GONE);
            eddireccion.setVisibility(View.GONE);
            // Mostrar la opción "peso_inicial" y "registro_peso"
            edpeso_inicial.setVisibility(View.VISIBLE);
            edregistro_peso.setVisibility(View.VISIBLE);
            ednombre.setVisibility(View.VISIBLE);
            edgrasa.setVisibility(View.VISIBLE);
            edimc.setVisibility(View.VISIBLE);
            edcintura.setVisibility(View.VISIBLE);
            rendimiento.setVisibility(View.VISIBLE);
            pesito.setVisibility(View.VISIBLE);
            uno.setVisibility(View.VISIBLE);
            dos.setVisibility(View.VISIBLE);
            tres.setVisibility(View.VISIBLE);
            cuatro.setVisibility(View.VISIBLE);
            registrosema.setVisibility(View.VISIBLE);
            grasa.setVisibility(View.VISIBLE);
            composicion.setVisibility(View.VISIBLE);
            imc.setVisibility(View.VISIBLE);
            imcc.setVisibility(View.VISIBLE);


        }else if (id == R.id.btnplan) {
            // Ocultar las demás opciones

            edtelefono.setVisibility(View.GONE);
            edcedula.setVisibility(View.GONE);
            edcorreo.setVisibility(View.GONE);
            eddireccion.setVisibility(View.GONE);
            edn_emergencia.setVisibility(View.GONE);
             edenfermedad.setVisibility(View.GONE);
             edemergencia.setVisibility(View.GONE);
             contacto.setVisibility(View.GONE);
             edlesiones.setVisibility(View.GONE);
             les.setVisibility(View.GONE);
             Lesion.setVisibility(View.GONE);
             lesiones.setVisibility(View.GONE);
            medica.setVisibility(View.GONE);
             enfermedad.setVisibility(View.GONE);
             enfer.setVisibility(View.GONE);
             Sick.setVisibility(View.GONE);
            cuenta.setVisibility(View.GONE);
            edpeso_inicial.setVisibility(View.GONE);
            edregistro_peso.setVisibility(View.GONE);
            edsemana.setVisibility(View.GONE);
            edgrasa.setVisibility(View.GONE);
            edimc.setVisibility(View.GONE);
            edcintura.setVisibility(View.GONE);
            edimc.setVisibility(View.GONE);
            rendimiento.setVisibility(View.GONE);
            pesito.setVisibility(View.GONE);
            uno.setVisibility(View.GONE);
            dos.setVisibility(View.GONE);
            tres.setVisibility(View.GONE);
            cuatro.setVisibility(View.GONE);
            registrosema.setVisibility(View.GONE);
            grasa.setVisibility(View.GONE);
            composicion.setVisibility(View.GONE);
            imc.setVisibility(View.GONE);
            imcc.setVisibility(View.GONE);
            // Mostrar la opción "peso_inicial" y "registro_peso"

            edmetas.setVisibility(View.VISIBLE);

            eddias.setVisibility(View.VISIBLE);
            edhorario.setVisibility(View.VISIBLE);
            edrutina.setVisibility(View.VISIBLE);
            eddieta.setVisibility(View.VISIBLE);
            plan.setVisibility(View.VISIBLE);
            ventas.setVisibility(View.VISIBLE);
            dias.setVisibility(View.VISIBLE);
            horario.setVisibility(View.VISIBLE);
            rutina.setVisibility(View.VISIBLE);
            dieta.setVisibility(View.VISIBLE);
            ednombre.setVisibility(View.VISIBLE);




        }else if (id == R.id.btnmedica) {
            // Ocultar las demás opciones


            edtelefono.setVisibility(View.GONE);
            edcedula.setVisibility(View.GONE);
            edcorreo.setVisibility(View.GONE);
            eddireccion.setVisibility(View.GONE);
            cuenta.setVisibility(View.GONE);
            edpeso_inicial.setVisibility(View.GONE);
            edregistro_peso.setVisibility(View.GONE);
            edsemana.setVisibility(View.GONE);
            edgrasa.setVisibility(View.GONE);
            edimc.setVisibility(View.GONE);
            edcintura.setVisibility(View.GONE);
            edimc.setVisibility(View.GONE);
            rendimiento.setVisibility(View.GONE);
            pesito.setVisibility(View.GONE);
            uno.setVisibility(View.GONE);
            dos.setVisibility(View.GONE);
            tres.setVisibility(View.GONE);
            cuatro.setVisibility(View.GONE);
            registrosema.setVisibility(View.GONE);
            grasa.setVisibility(View.GONE);
            composicion.setVisibility(View.GONE);
            imc.setVisibility(View.GONE);
            imcc.setVisibility(View.GONE);
            eddias.setVisibility(View.GONE);
            edhorario.setVisibility(View.GONE);
            edrutina.setVisibility(View.GONE);
            eddieta.setVisibility(View.GONE);
            plan.setVisibility(View.GONE);
            ventas.setVisibility(View.GONE);
            dias.setVisibility(View.GONE);
            horario.setVisibility(View.GONE);
            rutina.setVisibility(View.GONE);
            dieta.setVisibility(View.GONE);
            // Mostrar la opción "peso_inicial" y "registro_peso"

            edmetas.setVisibility(View.GONE);
            ednombre.setVisibility(View.VISIBLE);
             edenfermedad.setVisibility(View.VISIBLE);
             edemergencia.setVisibility(View.VISIBLE);
            edn_emergencia.setVisibility(View.VISIBLE);
             contacto.setVisibility(View.VISIBLE);
             edlesiones.setVisibility(View.VISIBLE);
            les.setVisibility(View.VISIBLE);
            Lesion.setVisibility(View.VISIBLE);
           lesiones.setVisibility(View.VISIBLE);
            medica.setVisibility(View.VISIBLE);
             enfermedad.setVisibility(View.VISIBLE);
             enfer.setVisibility(View.VISIBLE);
             Sick.setVisibility(View.VISIBLE);







        }else if (id == R.id.btnnota) {
            // Ocultar las demás opciones

            edn_emergencia.setVisibility(View.GONE);
            cuenta.setVisibility(View.VISIBLE);
            edpeso_inicial.setVisibility(View.GONE);
            edregistro_peso.setVisibility(View.GONE);
            edsemana.setVisibility(View.GONE);
            edgrasa.setVisibility(View.GONE);
            edimc.setVisibility(View.GONE);
            edcintura.setVisibility(View.GONE);
            edimc.setVisibility(View.GONE);
            rendimiento.setVisibility(View.GONE);
            pesito.setVisibility(View.GONE);
            uno.setVisibility(View.GONE);
            dos.setVisibility(View.GONE);
            tres.setVisibility(View.GONE);
            cuatro.setVisibility(View.GONE);
            registrosema.setVisibility(View.GONE);
            grasa.setVisibility(View.GONE);
            composicion.setVisibility(View.GONE);
            imc.setVisibility(View.GONE);
            imcc.setVisibility(View.GONE);
            eddias.setVisibility(View.GONE);
            edhorario.setVisibility(View.GONE);
            edrutina.setVisibility(View.GONE);
            eddieta.setVisibility(View.GONE);
            plan.setVisibility(View.GONE);
            ventas.setVisibility(View.GONE);
            dias.setVisibility(View.GONE);
            horario.setVisibility(View.GONE);
            rutina.setVisibility(View.GONE);
            dieta.setVisibility(View.GONE);
            edenfermedad.setVisibility(View.GONE);
            edemergencia.setVisibility(View.GONE);
            contacto.setVisibility(View.GONE);
            edlesiones.setVisibility(View.GONE);
            les.setVisibility(View.GONE);
            Lesion.setVisibility(View.GONE);
            lesiones.setVisibility(View.GONE);
            medica.setVisibility(View.GONE);
            enfermedad.setVisibility(View.GONE);
            enfer.setVisibility(View.GONE);
            Sick.setVisibility(View.GONE);
            edmetas.setVisibility(View.GONE);
            // Mostrar la opción "peso_inicial" y "registro_peso"


            ednombre.setVisibility(View.VISIBLE);
            edtelefono.setVisibility(View.VISIBLE);
            edcedula.setVisibility(View.VISIBLE);
            edcorreo.setVisibility(View.VISIBLE);
            eddireccion.setVisibility(View.VISIBLE);















        } else if (id == R.id.btndelete) {

            String idUser = edId.getText().toString().trim();

            removeUser(idUser);


        }

    }

    private void updateUser(final String nombre, final String telefono, final String cedula, final String correo, final String direccion, final String n_emergencia, final String id_metas, final String id_semanas, final String id_dias, final String horario,final String peso_inicial,final String registro_peso,final String rutina,final String dieta,final String imc,final String cintura,final String masa, final String lesion, final String descripcion1, final String sick, final String descripcion2, final String emergencia) {
        String URL="https://proyectgym.000webhostapp.com/edit.php";
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(view2.this, "se actualizo con exito", Toast.LENGTH_SHORT).show();


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String , String> params = new HashMap<>();
                params.put("id", id);
                params.put("nombre", nombre);
                params.put("telefono", telefono);
                params.put("cedula", cedula);
                params.put("correo", correo);
                params.put("direccion", direccion);
                params.put("n_emergencia", n_emergencia);
                params.put("id_metas", id_metas);
                params.put("id_semanas", id_semanas);
                params.put("id_dias", id_dias);
                params.put("horario", horario);
                params.put("peso_inicial", peso_inicial);
                params.put("registro_peso", registro_peso);
                params.put("rutina", rutina);
                params.put("dieta", dieta);
                params.put("imc", imc);
                params.put("cintura", cintura);
                params.put("masa", masa);
                params.put("lesion", lesion);
                params.put("descripcion1", descripcion1);
                params.put("sick", sick);
                params.put("descripcion2", descripcion2);
                params.put("emergencia", emergencia);
                return params;


            }
        };
        requestQueue.add(stringRequest);

    }



    private void removeUser(final String idUser) {
        String URL= "https://proyectgym.000webhostapp.com/delete.php";
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        finish();
                        Toast.makeText(view2.this, "eliminado correctamente", Toast.LENGTH_SHORT).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("id", idUser);
                return params;
            }
        };

        requestQueue.add(stringRequest);

    }

}